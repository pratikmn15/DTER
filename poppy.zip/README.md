## DIGITAL TWIN MINI PROJECT
### team members
#### Pratik Manjunath Naik - PES2UG22CS905
#### Yashwanth SD - PES2UG22CS677
#### Karthik B - PES2UG22CS257